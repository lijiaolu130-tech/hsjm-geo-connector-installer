# 华昇金玛 GEO 企业安全分支 V3

本分支基于 Wechatsync v2 的公开源码提交 `a98e42865387285afcc027c61836488748f3b30f`，用于华昇金玛 GEO 门户的本机草稿连接器。上游项目与本分支保持独立，门户不复制发布适配器实现。

## 能力边界

- 上游宣传的 29+ 平台来自官方成品扩展。
- 当前公开仓库内可审计的平台适配器为 19 个，另含 WordPress、Typecho、MetaWeblog 等 CMS 通道。
- 企业 V3 生产二进制只编译 `weixin`、`zhihu`、`baijiahao` 三个试点适配器；其余公开源码仅留在完整源码包中，不进入安装包运行时。
- 头条等部分平台的发布适配器位于未公开的 `private-adapters` 子模块；不能把官方成品的 29+ 平台描述为全部开源。
- 企业入口首批只开放微信公众号、知乎和百家号，并且每项草稿必须人工确认。公开发布、搜索收录、AI 引用、线索和成交必须有各自独立回执。

## 企业安全改动

1. 页面桥只注入华昇金玛 GEO 生产域名的顶层页面，不注入本地开发域名或任意网站。
2. 页面只暴露 `getAccounts` 与 `addTask`，不暴露图片上传、远程驱动、MCP、CMS、检查器或通用消息调用。
3. `addTask` 只接收批次、交接、内容、哈希、作物、平台、设备和尝试次数等任务元数据；正文必须从 `/api/distribution-executor/job` 回读。
4. 扩展复核当前门户身份、租户、工作区、任务所有者、设备领取、平台、尝试次数、高价值作物和 SHA-256 内容哈希。
5. 每项任务打开扩展自有确认窗口；批准按钮同时要求 `event.isTrusted` 和 `navigator.userActivation.isActive`。
6. 首批只允许 `weixin`、`zhihu`、`baijiahao`，并用 `chrome.storage.session` 阻止同一任务尝试重放。
7. 只有严格命中平台草稿编辑器 URL 才返回成功；返回门户前移除查询参数和片段，避免微信公众号 token 泄露。
8. Manifest 不再申请 `http://*/*`、`https://*/*`、`<all_urls>`、Cookie、Tabs、Scripting、Downloads、Alarms、ContextMenus 或 UnlimitedStorage 权限，只保留生产门户和三平台精确 HTTPS Host。
9. 独立企业后台是唯一 Service Worker；所有非 `HSJM_ENTERPRISE_*` 消息默认拒绝，不启动旧同步后台、MCP、CMS、远程配置、遥测或右键菜单。
10. `HSJM_ENTERPRISE_NETWORK_V3` 逐项校验协议、主机、端口、路径、方法和查询参数；只开放登录复核与纯文本草稿所需接口，并强制 `redirect: error`。
11. 请求正文只允许文本或 URL 表单；文件、Blob、流、图片上传和任意外部资源关闭。三个试点适配器的图片下载也必须经过同一网络策略。
12. 显式 Cookie 读取、导出、写入和删除全部关闭；平台会话只由浏览器在通过白名单的请求中自动携带，不进入门户或连接器业务数据。
13. DNR Header 规则只允许四个固定 HTTPS 过滤器及对应固定 Origin、Referer 或 `x-requested-with`，并只作用于扩展自身的 XHR。
14. 扩展按钮展示独立安全状态页，明确三平台、草稿确认和不保存密码/Cookie的边界。
15. 生产包不携带旧 `inject-api.js`、reader/Readability、编辑器、通用 popup、预处理器或同步对话框资产；源码仍完整保留用于 GPL 审计和未来独立评审。

## 验证

在仓库根目录安装与锁文件一致的依赖后执行：

```bash
pnpm --filter @wechatsync/extension typecheck
pnpm --filter @wechatsync/extension build
node --test packages/extension/security-tests/enterprise-dist-policy.test.mjs
node --test packages/extension/security-tests/enterprise-network-policy.test.mjs
```

安全回归覆盖：生产域名顶层白名单、D1 任务回读、内容哈希、三平台白名单、扩展人工确认、可信用户激活、严格草稿 URL 后置条件、页面 API 最小化、独立企业后台、精确 Host/接口/方法、内网与跳转拒绝、Cookie/脚本/下载关闭和旧高风险入口关闭。

## 运行

构建扩展后，在独立的 Chrome for Testing 或 Chromium 浏览器档案中加载：

```bash
pnpm --filter @wechatsync/extension build
# 在 chrome://extensions 打开开发者模式，加载 packages/extension/dist
```

Chrome 137 及以上正式版限制命令行 `--load-extension`，自动化空白档案验收应使用 Chrome for Testing。正式操作仍需用户在扩展确认窗口逐项批准；不通过页面脚本模拟批准。源码构建通过不等于 V3 已安装，必须另取安装后运行回执。
