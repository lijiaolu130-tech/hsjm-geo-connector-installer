# 华昇金玛 GEO 客户连接器交付说明

## 交付身份

- 产品：华昇金玛 GEO 草稿连接器
- 安全档案：`HSJM_ENTERPRISE_DRAFT_V2`
- 网络策略：`HSJM_ENTERPRISE_NETWORK_V3`
- 安装包版本：`2.0.9-hsjm-secure.5`
- 上游项目：Wechatsync v2 公开源码
- 上游基线提交：`a98e42865387285afcc027c61836488748f3b30f`
- 华昇金玛安全提交：以交付标签中的 `HSJM-RELEASE-METADATA.json` 为准
- 客户版功能基线提交：以交付标签中的 `HSJM-RELEASE-METADATA.json` 为准
- 许可证：GNU GPL v3；二进制交付必须同时提供对应完整源码与许可证

## 公开源码平台范围

本交付只包含公开仓库中可构建、可审计的 19 个平台适配器：

`51cto`、`baijiahao`、`bilibili`、`cnblogs`、`csdn`、`douban`、`eastmoney`、`imooc`、`juejin`、`oschina`、`segmentfault`、`sohu`、`weibo`、`weixin`、`woshipm`、`xueqiu`、`yuque`、`zhihu`、`zip-download`。

官方成品扩展标注的 29+ 平台还包括未公开适配器。本客户交付不包含 `dayu`、`douyin`、`jianshu`、`netease`、`smzdm`、`sohufocus`、`toutiao`、`x`、`xiaohongshu`、`yidian` 的私有发布实现，也不将这些平台描述为开源能力。

完整源码包保留上述 19 个公开适配器；V3 安装包运行时只编译 `weixin`、`zhihu`、`baijiahao` 三个试点适配器，其他源码不进入客户浏览器。

## 能力与回执边界

- 生产门户首批只允许微信公众号、知乎和百家号；每一项草稿写入都必须在扩展自有窗口中人工确认。
- 页面只传递任务元数据，扩展从 D1 回读规范正文并复核身份、租户、工作区、设备领取和 SHA-256。
- 企业 V3 只启动专用 Service Worker；旧页面通用 API、MCP、CMS、远程配置、遥测、图片路径和无人值守外部写入全部关闭。
- 草稿成功不等于公开发布、搜索收录、AI 引用、线索、成交或付款。
- 公开发布需要平台规则允许、人工复核并获得公开 URL 回执。
- 登录 Cookie 留在客户专用浏览器档案；门户不得保存账号密码、验证码、Cookie、Token 或私钥。连接器不申请 Cookie 权限，也不提供 Cookie 读取、导出、写入或删除接口。
- Manifest 只允许生产门户、微信公众号、知乎和百家号精确 HTTPS Host；内网、localhost、任意域名、任意跳转、二进制正文、外部图片和页面脚本执行均被拒绝。
- 为隔离平台登录态和控制影响范围，仍建议安装在独立 GEO 浏览器档案。

## 可复现验证

```bash
pnpm install --frozen-lockfile
pnpm --filter @wechatsync/extension build
pnpm --filter @wechatsync/extension typecheck
node --test packages/extension/security-tests/enterprise-dist-policy.test.mjs
node --test packages/extension/security-tests/enterprise-network-policy.test.mjs
```

当前预期验证结果：TypeScript 通过、生产构建通过、企业编译策略与网络策略全部通过。真实空白浏览器档案、门户所有者会话和三平台草稿仍需分别取得运行回执；不得把构建测试冒充已安装或真实平台草稿。实际交付提交号由发布目录中的 `HSJM-RELEASE-METADATA.json` 固化。

## 安装政策

客户安装未上架商店的本地扩展前，必须看到来源、许可证、权限和风险说明并明确确认。安装后先在专用浏览器档案逐个平台登录，再由门户检测账号摘要；任何验证码、主体认证、频率限制或平台审核只暂停对应连接器。
