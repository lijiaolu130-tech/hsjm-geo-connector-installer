(function () {
  'use strict';

  var ENTERPRISE_SECURITY_PROFILE = 'HSJM_ENTERPRISE_DRAFT_V2';
  var callbacks = Object.create(null);
  var statusHandler = null;

  function call(message, callback) {
    var eventID = 'evt_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 12);
    message.eventID = eventID;
    message.enterpriseSecurityProfile = ENTERPRISE_SECURITY_PROFILE;
    if (typeof callback === 'function') callbacks[eventID] = callback;
    window.postMessage(JSON.stringify(message), window.location.origin);
  }

  var connector = Object.freeze({
    versionNumber: 2000905,
    versionName: '2.0.9-hsjm-secure.5',
    enterpriseNetworkPolicy: 'HSJM_ENTERPRISE_NETWORK_V3',
    enterpriseSecurityProfile: ENTERPRISE_SECURITY_PROFILE,
    openSourceAdapterCount: 19,
    officialProductPlatformCount: 29,
    pilotPlatformIds: Object.freeze(['weixin', 'zhihu', 'baijiahao']),
    approvalRequired: true,
    automaticDraftCapable: false,
    secureDraftCapable: true,
    getAccounts: function (callback) {
      call({ method: 'getAccounts' }, callback);
    },
    addTask: function (task, onStatus, callback) {
      statusHandler = typeof onStatus === 'function' ? onStatus : null;
      call({ method: 'addTask', task: task }, callback);
    }
  });

  window.addEventListener('message', function (event) {
    if (event.source !== window || event.origin !== window.location.origin || typeof event.data !== 'string') return;
    var action;
    try { action = JSON.parse(event.data); } catch (_) { return; }
    if (!action || action.enterpriseSecurityProfile !== ENTERPRISE_SECURITY_PROFILE) return;
    if (action.method === 'taskUpdate') {
      if (statusHandler) statusHandler(action.task);
      return;
    }
    if (!action.callReturn || !action.eventID || !callbacks[action.eventID]) return;
    callbacks[action.eventID](action.result);
    delete callbacks[action.eventID];
  });

  window.$poster = connector;
  window.$syncer = connector;
}());
