(function () {
  'use strict';

  var requestId = new URLSearchParams(window.location.search).get('requestId') || '';
  var approve = document.getElementById('approve');
  var cancel = document.getElementById('cancel');
  var status = document.getElementById('status');
  var finished = false;

  function setStatus(message, kind) {
    status.textContent = message;
    status.className = 'status' + (kind ? ' ' + kind : '');
  }

  function send(type, payload) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ type: type, payload: payload }, function (response) {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (response && response.error) return reject(new Error(response.error));
        resolve(response || {});
      });
    });
  }

  async function load() {
    if (!/^approval_[a-f0-9]{32}$/.test(requestId)) throw new Error('确认请求编号无效');
    var response = await send('HSJM_ENTERPRISE_APPROVAL_READ', { requestId: requestId });
    var item = response.request;
    if (!item || item.publicPublish !== false) throw new Error('任务安全策略无效');
    document.getElementById('platform').textContent = item.platformName;
    document.getElementById('crop').textContent = item.crop;
    document.getElementById('article-title').textContent = item.title;
    document.getElementById('batch').textContent = item.batchId.slice(-18) + ' · 第' + item.attempt + '次';
    document.getElementById('excerpt').textContent = item.excerpt;
    approve.disabled = false;
    setStatus('校验通过，请确认是否写入该平台草稿箱');
  }

  approve.addEventListener('click', async function (event) {
    if (!event.isTrusted || !navigator.userActivation || !navigator.userActivation.isActive) {
      setStatus('必须由您本人点击确认按钮', 'error');
      return;
    }
    approve.disabled = true;
    cancel.disabled = true;
    setStatus('正在保存平台草稿，请勿关闭窗口…');
    try {
      var response = await send('HSJM_ENTERPRISE_APPROVE', { requestId: requestId });
      if (!response.success) throw new Error(response.error || '草稿后置条件未验证');
      finished = true;
      setStatus('草稿已保存并通过后置条件校验；未公开发布。', 'success');
      setTimeout(function () { window.close(); }, 1200);
    } catch (error) {
      finished = true;
      setStatus(error.message || '草稿保存失败', 'error');
    }
  });

  cancel.addEventListener('click', async function (event) {
    if (!event.isTrusted) return;
    finished = true;
    approve.disabled = true;
    cancel.disabled = true;
    try { await send('HSJM_ENTERPRISE_CANCEL', { requestId: requestId, reason: '用户取消了草稿写入' }); } catch (_) {}
    window.close();
  });

  window.addEventListener('pagehide', function () {
    if (!finished && /^approval_[a-f0-9]{32}$/.test(requestId)) {
      chrome.runtime.sendMessage({ type: 'HSJM_ENTERPRISE_CANCEL', payload: { requestId: requestId, reason: '确认窗口已关闭' } });
    }
  });

  load().catch(function (error) {
    approve.disabled = true;
    setStatus(error.message || '确认任务加载失败', 'error');
  });
}());
